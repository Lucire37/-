﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pokupka_auto
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\ko72x\OneDrive\Изображения\Standart.jpeg");
                textBox1.Text = ("300000");
            }

            if (radioButton2.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\ko72x\OneDrive\Изображения\Comfort.jpg");
                textBox1.Text = ("500000");
            }

            if (radioButton3.Checked)
            {
                pictureBox1.Image = Image.FromFile(@"C:\Users\ko72x\OneDrive\Изображения\Premium.jpg");
                textBox1.Text = ("700000");
            }
        }
    }
}
